import React from 'react';
import { StoreContext } from '../context/storeContext';

//describes the data that will be saved on the context
export default React.createContext({
    //data
    cart: [],
    user: {},

    addProductToCart: (product) => {},
    removeProdFromCart: (productId) => {},
});
