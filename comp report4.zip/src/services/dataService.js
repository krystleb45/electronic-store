import axios from "axios";

var catalog = [
    {
        _id: "1234343hhfhahudsf76",
            title: "laptop",
            image: "Laptop-computer.jpg",
            price: 1200.00,
            category: "laptops",
            stock: 10,
            minimum: 1,
        },
        {
            _id: "ththeuahtiuahet7494",
            title: "Desktop",
            image: "desktop.jpeg",
            price: 600.00,
            category: "desktop",
            stock: 10,
            minimum: 1,
        },
        {
            _id: "ththeuahtiuahet7494",
            title: "Modem",
            image: "modem.jpeg",
            price: 100.00,
            category: "modem",
            stock: 10,
            minimum: 1,
        },
        {
            _id: "ththeuahtiuahet7494",
            title: "printer",
            image: "printer.jpg",
            price: 500.00,
            category: "printer",
            stock: 10,
            minimum: 1,
        },
        {
            _id: "ththeuahtiuahet7494",
            title: "Cell Phone",
            image: "cell phone.jpeg",
            price: 1000.00,
            category: "phone",
            stock: 10,
            minimum: 1,
        },
        {
            _id: "ththeuahtiuahet7494",
            title: "Phone Charger",
            image: "phone charger.jpeg",
            price: 25.00,
            category: "accessories",
            stock: 10,
            minimum: 1,
        },
    

];

class DataService{
serverURL = "http://127.0.0.1:5000";

    async getCatalog(){
        //call the server to get catalog
        let res = await axios.get("http://127.0.0.1:5000/api/catalog");
        return res.data; // = an array of objects

        //return mock data (temporal)
        //return catalog;
    }

    //get categories
    //http://127.0.0.1:5000/api/categories
    async getCategories(){
        let res = await axios.get("http://127.0.0.1:5000/api/categories");
        return res.data;
    }

    async saveProduct(prod){
        let res = await axios.post("http://127.0.0.1:5000/api/catalog", prod)
        console.log("saving result", res.data);
        return res.data;
    }

    saveItem(){

    }
    saveOrder(){

    }
    async submitOrder(order){
    let res = await axios.post(this.serverURL + "/api/order", order);
    console.log("Result of saving order", res.data);
        }
}
export default DataService;