const CouponForm = () => {
  const handleSave = () => {
    console.log("Save discount");
  };

  return (
    <div className="coupon-form">
      <h3>Manage your discount coupons</h3>

      <div className="my-control">
        <label>Code</label>
        <input type="text" />
      </div>

      <div className="my-control">
        <label>Discount</label>
        <input type="number" />
      </div>

      <div className="my-control">
        <button onClick={handleSave} className="btn btn-dark">
          Register Item
        </button>
      </div>
    </div>
  );
};

export default CouponForm;
