import "./cart.css";
import { useContext } from "react";
import StoreContext from "../context/storeContext";
import Item from "./item";
import ItemInCart from "./itemInCart";
const Cart = () => {
  const saveTheOrder = () => {
    let ord = {
      product: cart,
      userId: 2139,
      coupon: "",
    };
    let service = new DataService();
    service.SubmitOrder(ord);
  };

  return (
    <div className="cart-page">
      <h1>Ready to Order?</h1>
      <h5>There are {cart.length} Items in your cart</h5>
      <hr />

      <div className="row">
        <div className="col-10 cart-containter">
          {Cart.map((prod) => (
            <ItemInCart key={prod._id} data={prod}></ItemInCart>
          ))}
        </div>

        <div className="col-2 total-container py-3">
          <h4>Your Total:</h4>
          <h3>{getTotal()}</h3>
          <hr />
          <div className="coupon">
            <label>Do you have a coupon?</label>
            {couponError ? (
              <div className="alert alert-danger">Invald Code </div>
            ) : null}
            <input
              placeholder="Apply coupon"
              type="text"
              name="code"
              onChange={codeChange}
            />
            <button className="btn btn-sm btn-dark" onClick={handleValidate}>
              Validate
            </button>
          </div>

          <hr />

          <button className="btn btn-block btn-primary" onClick={saveTheOrder}>
            💳 Proceed to Payment 💳
          </button>
        </div>
      </div>
    </div>
  );
};
export default Cart;
