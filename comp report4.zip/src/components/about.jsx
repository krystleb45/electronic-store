const About = () => {
  return (
    <div className="about-page">
      <h1>About</h1>
      <h5>Krystle Berry</h5>
      <hr />
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Illo veritatis
        quod temporibus, aut dolor quas, labore odio enim cumque, dolorem modi
        quam cupiditate! Omnis pariatur rem ullam dignissimos consectetur ipsa.
      </p>
    </div>
  );
};

export default About;
